#ifndef prelude_h
#define prelude_h

#define Char_c 1
#define EmptyString_c 2
#define String_c 3

#endif

