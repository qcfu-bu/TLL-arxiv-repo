#ifndef prelude_h
#define prelude_h

#define Char_c 5
#define EmptyString_c 6
#define String_c 7
#define Between_c 4

#endif

